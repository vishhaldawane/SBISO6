package one2one;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity @Table(name="emp_1")
public class Employee {//one employee got one passport
	@Id	private int employeeId;
		private String employeeName;
	
		@OneToOne
		Passport passport; //hasA
		
		
		
	public Passport getPassport() {
			return passport;
		}
		public void setPassport(Passport passport) {
			this.passport = passport;
		}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
}
