import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import one2one.Employee;

public class TestOneToOne {
	
	@Test
	public void addEmployeeWithoutPassport() {
		
		Employee emp = new Employee();
		System.out.println("Blank emp created...");
		emp.setEmployeeName("Jack");

		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();
			manager.persist(emp);
		tran.commit();
		
	}
}
