package com.sbi.demo.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.sbi.demo.entity.User;

public class MyUserDetails implements UserDetails {

	private String username;
	private String password;
	private boolean active;
	private List<GrantedAuthority> authorities;
	
	public MyUserDetails() {
		System.out.println("MyUserDetails()  ctor...");
	}
	public MyUserDetails(User user) {
		System.out.println("MyUserDetails(User)  ctor...");
		this.username = user.getUsername();
		this.password = user.getPassword();
		this.active = user.isIsactive();
		this.authorities = Arrays.stream(user.getRole()
			.split(",")).map(SimpleGrantedAuthority::new)
			.collect(Collectors.toList());
	//user.getRole() -> "USER,ENDUSER,POWERUSER,ADMIN,SALESMAN,ACCOUNANT"
	//.split         -> [] = {"USER","ENDUSER","POWERUSER","ADMIN","SALESMAN","ACCOUNANT"}
   // map -> converts the above tokens in SimpleGrantedAuthority token
		// collect -> convert it as a List
		
	}
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		System.out.println("getAuthorities()...");
		//return Arrays.asList(new SimpleGrantedAuthority("ROLE_USER"));
		return authorities;
	}

	@Override
	public String getPassword() {
//		password="pass";
		System.out.println("getPassword()..."+password);
		return password;
	}

	@Override
	public String getUsername() {
		System.out.println("getUserName()..."+username);
		return username;
	}

	@Override
	public boolean isAccountNonExpired() {
		System.out.println("isAccountNonLocked()");
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		System.out.println("isAccountNonLocked()");
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		System.out.println("isCredentialsNonExpired()....");
		return true;
	}

	@Override
	public boolean isEnabled() {
		System.out.println("isEnabled()....");
		return true;
	}

}
