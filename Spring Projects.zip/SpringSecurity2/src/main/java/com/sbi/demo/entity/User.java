package com.sbi.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/*
 * 
 * 
create table user_info
(
	id int primary key,
	username varchar(50),
	password varchar(200),
	isactive boolean,
	role varchar(20)
)
insert into user_info values (1,'vishal','jack',true,'ROLE_USER');
insert into user_info values (2,'root','abc',true,'ROLE_ADMIN');
insert into user_info values (3,'jack','jack123',true,'ROLE_USER');
insert into user_info values (4,'jane','jack223',true,'ROLE_USER');
*/

@Entity
@Table(name="user_info")
public class User {
	@Id	@GeneratedValue	
	
	private int id;
	private String username;
	private String password;
	private boolean isactive;
	private String role;
	
	
	
	public User() {
		super();
		System.out.println("User : pojo");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public boolean isIsactive() {
		return isactive;
	}
	public void setIsactive(boolean isactive) {
		this.isactive = isactive;
	}
	
}
