package com.sbi.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {

	public UserResource () {
		System.out.println("CONTROLLER :  UserResource()....");
	}
	@GetMapping("/home")
	public String homePage() {
		return "<h1>Welcome Home Page </h1>";
	}
	@GetMapping("/user")
	public String endUser() {
		return "<h1>Welcome End User</h1>";
	}
	@GetMapping("/admin")
	public String adminUser() {
		return "<h1>Welcome Admin User</h1>";
	}
}
