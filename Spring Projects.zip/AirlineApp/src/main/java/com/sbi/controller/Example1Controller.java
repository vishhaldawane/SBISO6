package com.sbi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.view.InternalResourceView;

//C
public class Example1Controller implements Controller {
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("handleRequest()...");
		View theView = new InternalResourceView("example1.jsp");//the jsp page
		ModelAndView mav = new ModelAndView(theView);
		mav.addObject("myMessage", "Welcome to Spring MVC Controller1");
		Student studObj = new Student();
		studObj.setRollno(111);
		studObj.setName("Julie1");
		mav.addObject("myStudent", studObj);
		return mav;
	}
	public Example1Controller() {
		super();
		System.out.println("CONTROLLER1 : Example1Controller" );
	}

}
