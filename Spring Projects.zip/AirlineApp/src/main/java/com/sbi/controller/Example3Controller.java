package com.sbi.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
//import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.view.InternalResourceView;

//C
@Controller
public class Example3Controller  {
	
	@RequestMapping("/example3.do")
	public String anyMethodName(Map model)  {
		System.out.println("anyMethodName()...");
		model.put("myMessage", "Welcome to Spring MVC Controller3");
		return "example1";
	}
	
	public Example3Controller() {
		super();
		System.out.println("CONTROLLER3 : Example1Controller" );
	}

}
