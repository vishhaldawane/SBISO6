package com.sbi.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
//import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.view.InternalResourceView;

//C
@Controller
public class Example4Controller  {
	List<Student> listOfStudents = new ArrayList<Student>();
	
	@RequestMapping("/example4.do")
	public @ResponseBody List<Student> getAllStudents1()  {
		System.out.println("getAllStudents1()...");
		return listOfStudents;
	}
	
	@RequestMapping(value="/example5.do", 
			method=RequestMethod.GET,
			produces = "application/json")
	public @ResponseBody StudentList getAllStudents2()  {
		System.out.println("getAllStudents2()...");
		StudentList list = new StudentList();
		list.setListOfStudents(listOfStudents);
		return list;
	}
	
	public Example4Controller() {
		System.out.println("CONTROLLER4 : Example1Controller" );
		listOfStudents.add(new Student(101,"Jack")); 
		listOfStudents.add(new Student(102,"Jane"));
		listOfStudents.add(new Student(103,"Julie"));
		listOfStudents.add(new Student(104,"Julia"));
		listOfStudents.add(new Student(105,"Janet"));
	}

}
