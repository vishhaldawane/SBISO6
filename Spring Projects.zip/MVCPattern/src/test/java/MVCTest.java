import org.junit.jupiter.api.Test;

import com.sbi.controller.StudentController;
import com.sbi.model.Student;
import com.sbi.view.StudentView;

public class MVCTest {
	
	@Test
	public void testMvc() {
		
		Student model = new Student();//MODEL
		model.setRollno(123456);
		model.setName("Jackie");
		
		StudentView view = new StudentView(); //VIEW
		
		StudentController controller = 
				new StudentController(model,view);//CONTROLLER
		
		controller.updateView();
		
		controller.setStudentRollNumber(654321);//CHANGE model
		controller.setStudentName("JANEIT");//CHANGE model
		
		controller.updateView(); //refresh the VIEW
	}
}
