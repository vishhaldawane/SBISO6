package com.sbi.view;

import com.sbi.model.Student;

//V - View is aware of the Model
public class StudentView {
	public void printStudentDetails(
			Student x) {
		System.out.println("+----------------------+");
		System.out.println("|    STUDENT VIEW      |");
		System.out.println("+----------------------+");
		System.out.println("| Roll Number  : "+x.getRollno()+"|");
		System.out.println("| Student Name : "+x.getName()+"|");
		System.out.println("+----------------------+");
	}
}
