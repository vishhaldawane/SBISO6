package com.sbi.demo.layer1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity(name = "flight_info")
public class Flight {

	@Id
	@GeneratedValue
	private int flightNumber;
	
	private String flightName;
	private String flightSource;
	private String flightDestination;
	
	//FlightDetails flightDetails  = new FlightDetails();
	
	public void fly() {
		System.out.println("Flight is flying...");
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightSource() {
		return flightSource;
	}

	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}

	public String getFlightDestination() {
		return flightDestination;
	}

	public void setFlightDestination(String flightDestination) {
		this.flightDestination = flightDestination;
	}
	
	
}
