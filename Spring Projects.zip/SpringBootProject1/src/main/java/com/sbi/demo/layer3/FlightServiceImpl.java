package com.sbi.demo.layer3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.layer1.Flight;
import com.sbi.demo.layer2.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepo;
	
	@Override
	public Flight searchFlightBySource(String src) 
	throws FlightNotFoundException {
		
		System.out.println("BL: ");
			Iterable<Flight> iterable = flightRepo.findAll();
			Iterator<Flight> iterator = iterable.iterator();
			boolean flightFound=false;
			while(iterator.hasNext()) {
				Flight flight = iterator.next();
				if(flight.getFlightSource().equalsIgnoreCase(src))
				{
					flightFound=true;
					return flight;
				}
			}
			if(flightFound==false)
				throw new FlightNotFoundException("This flight source does not exist!!! : "+src);
			
		return null;
	}

	@Override
	public void addFlightService(Flight newFlight) 
			throws FlightAlreadyExistsException {
		Iterable<Flight> iterable = flightRepo.findAll();
		Iterator<Flight> iterator = iterable.iterator();
		boolean flightFound=false;
		while(iterator.hasNext()) {
			Flight flight = iterator.next();
			if(flight.getFlightNumber() == 
					newFlight.getFlightNumber()) {
				flightFound=true;
				throw new FlightAlreadyExistsException("This flight already exists : "+newFlight.getFlightNumber());
			}
		}
		if(flightFound==false)
			flightRepo.save(newFlight);
	}

	@Override
	public void modifyFlightService(Flight flightToModify) throws FlightNotFoundException {
		Iterable<Flight> iterable = flightRepo.findAll();
		Iterator<Flight> iterator = iterable.iterator();
		boolean flightFound=false;
		while(iterator.hasNext()) {
			Flight flight = iterator.next();
			if(flight.getFlightNumber() == flightToModify.getFlightNumber())
			{
				flightFound=true;
				flightRepo.save(flightToModify);
				break;	
			}
		}
		if(flightFound==false)
			throw new FlightNotFoundException("This flight does not exists : "+flightToModify.getFlightNumber());			
	}

	@Override
	public void deleteFlightService(int flightId) throws FlightNotFoundException {

		Iterable<Flight> iterable = flightRepo.findAll();
		Iterator<Flight> iterator = iterable.iterator();
		boolean flightFound=false;
		
		while(iterator.hasNext()) {
			Flight flight = iterator.next();
			if(flight.getFlightNumber() == flightId)
			{
				flightFound=true;
				flightRepo.deleteById(flightId);
				break;	
			}
		}
		if(flightFound==false)
			throw new FlightNotFoundException("This flight does not exists : "+flightId);			
		
	}

	@Override
	public Flight getFlightService(int flightId) throws FlightNotFoundException {
	
		System.out.println("BL: ");
		Iterable<Flight> iterable = flightRepo.findAll();
		Iterator<Flight> iterator = iterable.iterator();
		boolean flightFound=false;
		while(iterator.hasNext()) {
			Flight flight = iterator.next();
			if(flight.getFlightNumber()==flightId)
			{
				flightFound=true;
				return flight;
			}
		}
		if(flightFound==false)
			throw new FlightNotFoundException("This flight source does not exist!!! : "+flightId);
		
	return null;
		
	}

	@Override
	public List<Flight> getFlightsService() {
		List<Flight> flightList = new ArrayList<Flight>();
		System.out.println("BL: ");
		Iterable<Flight> iterable = flightRepo.findAll();
		Iterator<Flight> iterator = iterable.iterator();
		boolean flightFound=false;
		while(iterator.hasNext()) {
			Flight flight = iterator.next();
			flightList.add(flight);
		}
		
		
		return flightList;
		
	}

}
