import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.entity.Flight;
import com.sbi.repo.FlightRepository;



@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring3.xml"} )
public class FlightTest {
	
	@Autowired
	FlightRepository flightRepo; //which bean to inject?
	
	@Test
	public void selectAllFlightsTest()
	{
		List<Flight> listOfFlights =  flightRepo.selectAllFlights();
		for (Flight flight : listOfFlights) {
			System.out.println("Flight : "+flight);
		}
		
	}
	
	@Test
	public void insertFlightTest() {
		Flight flightToModify = new Flight();
		flightToModify.setFlightNumber(420);
		flightToModify.setFlightName("AIR CHINA");
		flightToModify.setFlightSource("BOMBAY");
		flightToModify.setFlightDest("NOWHERE");
		flightRepo.insertFlight(flightToModify);
	}
}




