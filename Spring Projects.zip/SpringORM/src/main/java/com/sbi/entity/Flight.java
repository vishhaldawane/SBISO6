package com.sbi.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity // uniquely identified by its pk
@Table(name="flights")
public class Flight { //2
	
	@Id //its a primary key column
	private int flightNumber;
	
	private String flightName;
	private String flightSource;
	private String flightDest;
	
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightSource() {
		return flightSource;
	}
	public void setFlightSource(String flightSource) {
		this.flightSource = flightSource;
	}
	public String getFlightDest() {
		return flightDest;
	}
	public void setFlightDest(String flightDest) {
		this.flightDest = flightDest;
	}
	
	@Override
	public String toString() {
		return "Flight [flightNumber=" + flightNumber + ", flightName=" + flightName + ", flightSource=" + flightSource
				+ ", flightDest=" + flightDest + "]";
	}
	
	
	
	
	
	
	
}
