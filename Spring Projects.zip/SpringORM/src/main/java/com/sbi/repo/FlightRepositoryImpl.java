package com.sbi.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sbi.entity.Flight;

@Repository
public class FlightRepositoryImpl implements FlightRepository {

	@PersistenceContext
	EntityManager entityManager;
	
	public FlightRepositoryImpl() {
		System.out.println("FlightRepositoryImpl() with @PersistenceContext");
	}
	
	@Transactional
	public void insertFlight(Flight flight) {
		entityManager.persist(flight);

	}

	
	public List<Flight> selectAllFlights() {
		Query theQuery = entityManager.createQuery("from Flight"); //not SQL, rather it is JPQL
		return theQuery.getResultList();
	}

	
	public Flight selectFlight(int flno) {
		return entityManager.find(Flight.class, flno);

	}

	@Transactional
	public void updateFlight(Flight flight) {
		entityManager.merge(flight);

	}

	@Transactional
	public void deleteFlight(Flight flight) {
		Flight foundFlight = entityManager.find(Flight.class, flight.getFlightNumber());
		entityManager.remove(foundFlight);
	}

}
