package com.sbi;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarTest {
	@Test public void createCarTest() {
		
		Piston pist1 = new Piston();
		Engine theEng1 = new Engine();
		Car carObj1 = new Car();
		carObj1.drive();
		
		System.out.println("Car object  : "+carObj1.hashCode());

		Piston pist2 = new Piston();
		Engine theEng2 = new Engine();
		Car carObj2 = new Car();
		carObj1.drive();
		
		System.out.println("Car object  : "+carObj2.hashCode());
		
		
	}
	
	@Test
	public void createVehicle() {
		VehicleFactory vehicleFactory = new VehicleFactory();
		Vehicle v1 = vehicleFactory.getVehicle();
		Vehicle v2 = vehicleFactory.getVehicle();
		Vehicle v3 = vehicleFactory.getVehicle();
	}
	
	@Test
	public void springWayToCreateVehicle() {
		System.out.println(">>> Trying to create spring container...");
		ApplicationContext ctx = new 
				ClassPathXmlApplicationContext("myspring2.xml");
		System.out.println(">>> spring container...created..........");
	}
	
}













