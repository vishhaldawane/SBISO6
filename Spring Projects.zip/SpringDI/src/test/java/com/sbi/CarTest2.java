package com.sbi;
import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarTest2 {
	
	
	@Test
	public void springWayToCreateVehicle() {
		System.out.println(">>> Trying to create spring container...");
		ApplicationContext ctx = new 
				ClassPathXmlApplicationContext("myspring3.xml");
		System.out.println(">>> spring container...created..........");
		
		com.sbi.newcar.Car theCarObj1 = ctx.getBean(com.sbi.newcar.Car.class); //.class is a static data member of Class type
		com.sbi.newcar.Car theCarObj2 = ctx.getBean(com.sbi.newcar.Car.class); //.class is a static data member of Class type
		com.sbi.newcar.Car theCarObj3 = ctx.getBean(com.sbi.newcar.Car.class); //.class is a static data member of Class type
		
		System.out.println("theCarObj1 "+theCarObj1.hashCode());
		System.out.println("theCarObj2 "+theCarObj2.hashCode());
		System.out.println("theCarObj3 "+theCarObj3.hashCode());
		
		
	}
	
}













