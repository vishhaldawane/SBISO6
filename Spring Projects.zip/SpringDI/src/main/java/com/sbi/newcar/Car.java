package com.sbi.newcar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component //no need to write the <bean> tag
@Scope("prototype")
public class Car implements Vehicle {


	Engine theEngine;

	
	public Car(Engine theEng) {
		System.out.println("com.sbi.newcar.Car(Engine) ctor.." + this);
		theEngine = theEng;
	}
	
	//@Autowired
	/*public Car(Engine theEng, @Value("10") Integer i) {
		System.out.println("com.sbi.newcar.Car(Engine, int) ctor.." + this);
		theEngine = theEng;
	}*/
	
	//@Autowired
	public void setTheEngine(Engine theEng) {
		System.out.println("setTheEngine(Engine) setter..");
	}

	public void drive() { // mandate to define this method
		theEngine.startTheEngine();
		System.out.println("Driving the Car....");
	}
}
