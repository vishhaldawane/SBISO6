package com.sbi.newcar;

import org.springframework.stereotype.Component;

@Component 
public class Piston {
	
	public Piston() {
		System.out.println("com.sbi.newcar.Piston() ctor..."+this);
	}
	
	public void setPiston() {
		System.out.println("setPiston() setter...");
	}
	
	void fireThePiston() {
		System.out.println("Firing the Piston...");
	}
}
