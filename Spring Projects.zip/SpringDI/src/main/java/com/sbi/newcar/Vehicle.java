package com.sbi.newcar;

public interface Vehicle {
	void drive();
}
