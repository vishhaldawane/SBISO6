package com.sbi.newcar;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component 
public class Engine {

	//@Autowired
	Piston thePiston;

	public Engine(Piston thePist) {
		System.out.println("com.sbi.newcar.Engine(Piston) ctor..." + this);
		thePiston = thePist;
	}

	
	public void setThePiston(Piston thePist) {
		System.out.println("setThePiston(Piston) setter...");
	}

	void startTheEngine() {
		thePiston.fireThePiston();
		System.out.println("Starting the engine...");
	}
}
