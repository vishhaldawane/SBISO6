package com.sbi;
public class Car implements Vehicle {
	
	Engine theEngine;
	
	/*
	 * public Car( Engine theEng ) { System.out.println("Car(Engine) ctor.."+this);
	 * theEngine = theEng; }
	 */
	public void setTheEngine(Engine theEng) { 
		System.out.println("setTheEngine(Engine) setter..");
	}
	public void drive() { //mandate to define this method
		//theEngine.startTheEngine();
		System.out.println("Driving the Car....");
	}
}
