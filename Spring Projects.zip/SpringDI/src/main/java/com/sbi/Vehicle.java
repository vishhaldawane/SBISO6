package com.sbi;

public interface Vehicle {
	void drive();
}
