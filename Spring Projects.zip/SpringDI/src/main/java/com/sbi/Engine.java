package com.sbi;

public class Engine {
	
	Piston thePiston;
	
	/*
	 * public Engine(Piston thePist ) {
	 * System.out.println("Engine(Piston) ctor..."+this); thePiston = thePist; }
	 */
	public void setThePiston(Piston thePist) {
		System.out.println("setThePiston(Piston) setter...");
	}
	
	void startTheEngine() {
		thePiston.fireThePiston();
		System.out.println("Starting the engine...");
	}
}
