package com.sbi;
public class VehicleFactory {
	public Vehicle getVehicle() {
		
		Piston pist = new Piston();
		
		Engine theEng = new Engine();
		theEng.setThePiston(pist);
		
		Car carObj = new Car();
		carObj.setTheEngine(theEng);
		
		return carObj;
	}
}
