package com.sbi.layer3;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Product;

@Repository
public interface ProductRepository {
	void reduceStock(int productId, int quantity);
}
