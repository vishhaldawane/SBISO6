package com.sbi;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Order;
import com.sbi.layer4.OnlineShopping;



@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring3.xml"} )
public class OrderTest {
	
	@Autowired
	private OnlineShopping onlineShopping;
	
	@Test
	public void testOrder() {
		Order order = new Order();
		order.setProductId(123);
		order.setPrice(1200);
		order.setQuantity(5); //6000/- bill
		
		onlineShopping.placeOrder(order);
		
	}
	
}




