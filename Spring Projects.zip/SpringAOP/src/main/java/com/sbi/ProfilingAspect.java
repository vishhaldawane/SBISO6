package com.sbi;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Aspect @Component
public class ProfilingAspect {

	@Around("execution(* *(..))")
	public Object profile(ProceedingJoinPoint joinPoint) {
		StopWatch watch = new StopWatch();
		Object obj=null;
		watch.start(joinPoint.getSignature().getName());
		try {
			 obj = joinPoint.proceed();//invoke the target method
		} catch (Throwable e) {
			e.printStackTrace();
		} 
		finally {
			watch.stop();
			System.out.println(watch.prettyPrint());
		}
		return obj;
	}
}
