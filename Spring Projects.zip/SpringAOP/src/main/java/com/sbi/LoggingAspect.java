package com.sbi;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	@Before("execution(public * apply*(..))")
	public void log(JoinPoint joinPoint) {
		System.out.println("\n>> Its a common logging method executed ....<<"+joinPoint);
		Object proxyObject = joinPoint.getThis();
		Object targetObject = joinPoint.getTarget();
		Object args[] =joinPoint.getArgs();
		Signature sign = joinPoint.getSignature();
		
		System.out.println("Proxy object  : "+proxyObject);
		System.out.println("Target object : "+targetObject);
		System.out.println("Object args   : "+args);
		System.out.println("Sign          : "+sign);
		
		
	}
}

/*
   LoggingAspect logAsp = new LoggingAspect();
   logAsp.log();
  
 	OnlineService onlineServ = new ....
 	
 	logAsp.log();
 	onlineServ.applyForCheque();
 	
 	onlineServ.stopCheque();
 	
 	logAsp.log();
 	onlineServ.applyForCreditCard();
 	
 	onlineServ.getBalance();
   
 */
