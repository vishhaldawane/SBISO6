package com.sbi;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect @Component public class ExceptionHandlerAspect{
	@AfterThrowing("execution(* someBusinessMethod(..))")
	public void handleException(JoinPoint jp) throws Throwable 
	{
		System.out.println("...ROUTINE EXCEPTION HANDLER CODE HERE...");
		System.out.println("lets see who has raised an exception....");
		System.out.println("=========================");
		System.out.println(jp.getSignature().getName());
		System.out.println("=========================");
		throw new BusinessException("EXCEPTION : "+jp.getSignature().getName() + " has some exception ");
	}
}
