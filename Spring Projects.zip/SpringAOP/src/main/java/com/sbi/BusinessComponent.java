package com.sbi;

import org.springframework.stereotype.Component;

@Component
public class BusinessComponent implements BusinessInterface {
	public void someBusinessMethod() throws BusinessException {
		//some logic here..
		System.out.println(">>> INVOKING SOME BUSINESS METHOD <<< ");
		throw new BusinessException();
	}

}
