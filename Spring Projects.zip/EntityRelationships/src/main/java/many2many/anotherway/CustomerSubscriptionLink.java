package many2many.anotherway;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="customer_subscription_link2")
public class CustomerSubscriptionLink {

	@Id
	@GeneratedValue
	private int idValue;
	
	@ManyToOne
	@JoinColumn(name="c_id")
	private Customer customer;
	
	@ManyToOne
	@JoinColumn(name="s_id")
	private Subscription subscription;
	
	private LocalDate subscriptionDate;

	public int getIdValue() {
		return idValue;
	}

	public void setIdValue(int idValue) {
		this.idValue = idValue;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Subscription getSubscription() {
		return subscription;
	}

	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
	}

	public LocalDate getSubscriptionDate() {
		return subscriptionDate;
	}

	public void setSubscriptionDate(LocalDate subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}

	
}

