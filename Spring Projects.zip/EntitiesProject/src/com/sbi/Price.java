// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity
@Table(name="PRICE", indexes={@Index(name="pricePriceIndex", columnList="PRODID,STARTDATE")})
@G9Class(tableName="PRICE", isPersistent=true)
public class Price implements Serializable {

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Column(name="PRODID", nullable=false, precision=6)
    @G9Attribute(isPersistent=true, precision=6, columnName="PRODID", isNotNull=true)
    private BigDecimal prodid;
    @Column(name="STDPRICE", precision=8, scale=2)
    @G9Attribute(isPersistent=true, precision=8, scale=2, columnName="STDPRICE")
    private BigDecimal stdprice;
    @Column(name="MINPRICE", precision=8, scale=2)
    @G9Attribute(isPersistent=true, precision=8, scale=2, columnName="MINPRICE")
    private BigDecimal minprice;
    @Column(name="STARTDATE")
    @G9Attribute(isPersistent=true, columnName="STARTDATE")
    private LocalDateTime startdate;
    @Column(name="ENDDATE")
    @G9Attribute(isPersistent=true, columnName="ENDDATE")
    private LocalDateTime enddate;
    @G9Attribute(isIndex=true)
    private PricePriceIndex pricePriceIndex;

    /** Default constructor. */
    public Price() {
        super();
    }

    /**
     * Access method for prodid.
     *
     * @return the current value of prodid
     */
    public BigDecimal getProdid() {
        return prodid;
    }

    /**
     * Setter method for prodid.
     *
     * @param aProdid the new value for prodid
     */
    public void setProdid(BigDecimal aProdid) {
        prodid = aProdid;
    }

    /**
     * Access method for stdprice.
     *
     * @return the current value of stdprice
     */
    public BigDecimal getStdprice() {
        return stdprice;
    }

    /**
     * Setter method for stdprice.
     *
     * @param aStdprice the new value for stdprice
     */
    public void setStdprice(BigDecimal aStdprice) {
        stdprice = aStdprice;
    }

    /**
     * Access method for minprice.
     *
     * @return the current value of minprice
     */
    public BigDecimal getMinprice() {
        return minprice;
    }

    /**
     * Setter method for minprice.
     *
     * @param aMinprice the new value for minprice
     */
    public void setMinprice(BigDecimal aMinprice) {
        minprice = aMinprice;
    }

    /**
     * Access method for startdate.
     *
     * @return the current value of startdate
     */
    public LocalDateTime getStartdate() {
        return startdate;
    }

    /**
     * Setter method for startdate.
     *
     * @param aStartdate the new value for startdate
     */
    public void setStartdate(LocalDateTime aStartdate) {
        startdate = aStartdate;
    }

    /**
     * Access method for enddate.
     *
     * @return the current value of enddate
     */
    public LocalDateTime getEnddate() {
        return enddate;
    }

    /**
     * Setter method for enddate.
     *
     * @param aEnddate the new value for enddate
     */
    public void setEnddate(LocalDateTime aEnddate) {
        enddate = aEnddate;
    }

}
