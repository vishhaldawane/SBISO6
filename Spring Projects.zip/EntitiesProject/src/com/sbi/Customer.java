// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Association;
import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="CUSTOMER")
@G9Class(tableName="CUSTOMER", isPersistent=true)
public class Customer implements Serializable {

    /** Primary key. */
    protected static final String PK = "custid";

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Id
    @Column(name="CUSTID", unique=true, nullable=false, precision=6)
    @G9Attribute(isPersistent=true, precision=6, columnName="CUSTID", isPrimaryKey=true, isUnique=true, isNotNull=true, isIndex=true)
    private BigDecimal custid;
    @Column(name="NAME", length=45)
    @G9Attribute(isPersistent=true, dbLength=45, columnName="NAME")
    private String name;
    @Column(name="ADDRESS", length=40)
    @G9Attribute(isPersistent=true, dbLength=40, columnName="ADDRESS")
    private String address;
    @Column(name="CITY", length=30)
    @G9Attribute(isPersistent=true, dbLength=30, columnName="CITY")
    private String city;
    @Column(name="STATE", length=2)
    @G9Attribute(isPersistent=true, dbLength=2, columnName="STATE")
    private String state;
    @Column(name="ZIP", length=9)
    @G9Attribute(isPersistent=true, dbLength=9, columnName="ZIP")
    private String zip;
    @Column(name="AREA", precision=3)
    @G9Attribute(isPersistent=true, precision=3, columnName="AREA")
    private BigDecimal area;
    @Column(name="PHONE", length=9)
    @G9Attribute(isPersistent=true, dbLength=9, columnName="PHONE")
    private String phone;
    @Column(name="REPID", nullable=false, precision=4)
    @G9Attribute(isPersistent=true, precision=4, columnName="REPID", isNotNull=true)
    private BigDecimal repid;
    @Column(name="CREDITLIMIT", precision=9, scale=2)
    @G9Attribute(isPersistent=true, precision=9, scale=2, columnName="CREDITLIMIT")
    private BigDecimal creditlimit;
    @Column(name="COMMENTS")
    @G9Attribute(isPersistent=true, columnName="COMMENTS")
    private String comments;
    @OneToMany(mappedBy="customer")
    @G9Association(name="ordForeignKey", isPersistent=true, oppositeRole="customer", ownerRole="customer")
    private Set<Ord> ord;

    /** Default constructor. */
    public Customer() {
        super();
    }

    /**
     * Access method for custid.
     *
     * @return the current value of custid
     */
    public BigDecimal getCustid() {
        return custid;
    }

    /**
     * Setter method for custid.
     *
     * @param aCustid the new value for custid
     */
    public void setCustid(BigDecimal aCustid) {
        custid = aCustid;
    }

    /**
     * Access method for name.
     *
     * @return the current value of name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter method for name.
     *
     * @param aName the new value for name
     */
    public void setName(String aName) {
        name = aName;
    }

    /**
     * Access method for address.
     *
     * @return the current value of address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Setter method for address.
     *
     * @param aAddress the new value for address
     */
    public void setAddress(String aAddress) {
        address = aAddress;
    }

    /**
     * Access method for city.
     *
     * @return the current value of city
     */
    public String getCity() {
        return city;
    }

    /**
     * Setter method for city.
     *
     * @param aCity the new value for city
     */
    public void setCity(String aCity) {
        city = aCity;
    }

    /**
     * Access method for state.
     *
     * @return the current value of state
     */
    public String getState() {
        return state;
    }

    /**
     * Setter method for state.
     *
     * @param aState the new value for state
     */
    public void setState(String aState) {
        state = aState;
    }

    /**
     * Access method for zip.
     *
     * @return the current value of zip
     */
    public String getZip() {
        return zip;
    }

    /**
     * Setter method for zip.
     *
     * @param aZip the new value for zip
     */
    public void setZip(String aZip) {
        zip = aZip;
    }

    /**
     * Access method for area.
     *
     * @return the current value of area
     */
    public BigDecimal getArea() {
        return area;
    }

    /**
     * Setter method for area.
     *
     * @param aArea the new value for area
     */
    public void setArea(BigDecimal aArea) {
        area = aArea;
    }

    /**
     * Access method for phone.
     *
     * @return the current value of phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Setter method for phone.
     *
     * @param aPhone the new value for phone
     */
    public void setPhone(String aPhone) {
        phone = aPhone;
    }

    /**
     * Access method for repid.
     *
     * @return the current value of repid
     */
    public BigDecimal getRepid() {
        return repid;
    }

    /**
     * Setter method for repid.
     *
     * @param aRepid the new value for repid
     */
    public void setRepid(BigDecimal aRepid) {
        repid = aRepid;
    }

    /**
     * Access method for creditlimit.
     *
     * @return the current value of creditlimit
     */
    public BigDecimal getCreditlimit() {
        return creditlimit;
    }

    /**
     * Setter method for creditlimit.
     *
     * @param aCreditlimit the new value for creditlimit
     */
    public void setCreditlimit(BigDecimal aCreditlimit) {
        creditlimit = aCreditlimit;
    }

    /**
     * Access method for comments.
     *
     * @return the current value of comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * Setter method for comments.
     *
     * @param aComments the new value for comments
     */
    public void setComments(String aComments) {
        comments = aComments;
    }

    /**
     * Access method for ord.
     *
     * @return the current value of ord
     */
    public Set<Ord> getOrd() {
        return ord;
    }

    /**
     * Setter method for ord.
     *
     * @param aOrd the new value for ord
     */
    public void setOrd(Set<Ord> aOrd) {
        ord = aOrd;
    }

    /**
     * Compares the key for this instance with another Customer.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class Customer and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof Customer)) {
            return false;
        }
        Customer that = (Customer) other;
        Object myCustid = this.getCustid();
        Object yourCustid = that.getCustid();
        if (myCustid==null ? yourCustid!=null : !myCustid.equals(yourCustid)) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another Customer.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Customer)) return false;
        return this.equalKeys(other) && ((Customer)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        if (getCustid() == null) {
            i = 0;
        } else {
            i = getCustid().hashCode();
        }
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[Customer |");
        sb.append(" custid=").append(getCustid());
        sb.append("]");
        return sb.toString();
    }

    /**
     * Return all elements of the primary key.
     *
     * @return Map of key names to values
     */
    public Map<String, Object> getPrimaryKey() {
        Map<String, Object> ret = new LinkedHashMap<String, Object>(6);
        ret.put("custid", getCustid());
        return ret;
    }

}
