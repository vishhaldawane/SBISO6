// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Association;
import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="DEPT")
@G9Class(tableName="DEPT", isPersistent=true)
public class Dept implements Serializable {

    /** Primary key. */
    protected static final String PK = "deptno";

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Id
    @Column(name="DEPTNO", unique=true, nullable=false, precision=2)
    @G9Attribute(isPersistent=true, precision=2, columnName="DEPTNO", isPrimaryKey=true, isUnique=true, isNotNull=true, isIndex=true)
    private BigDecimal deptno;
    @Column(name="DNAME", length=14)
    @G9Attribute(isPersistent=true, dbLength=14, columnName="DNAME")
    private String dname;
    @Column(name="LOC", length=13)
    @G9Attribute(isPersistent=true, dbLength=13, columnName="LOC")
    private String loc;
    @OneToMany(mappedBy="dept")
    @G9Association(name="empForeignKey", isPersistent=true, oppositeRole="dept", ownerRole="dept")
    private Set<Emp> emp;

    /** Default constructor. */
    public Dept() {
        super();
    }

    /**
     * Access method for deptno.
     *
     * @return the current value of deptno
     */
    public BigDecimal getDeptno() {
        return deptno;
    }

    /**
     * Setter method for deptno.
     *
     * @param aDeptno the new value for deptno
     */
    public void setDeptno(BigDecimal aDeptno) {
        deptno = aDeptno;
    }

    /**
     * Access method for dname.
     *
     * @return the current value of dname
     */
    public String getDname() {
        return dname;
    }

    /**
     * Setter method for dname.
     *
     * @param aDname the new value for dname
     */
    public void setDname(String aDname) {
        dname = aDname;
    }

    /**
     * Access method for loc.
     *
     * @return the current value of loc
     */
    public String getLoc() {
        return loc;
    }

    /**
     * Setter method for loc.
     *
     * @param aLoc the new value for loc
     */
    public void setLoc(String aLoc) {
        loc = aLoc;
    }

    /**
     * Access method for emp.
     *
     * @return the current value of emp
     */
    public Set<Emp> getEmp() {
        return emp;
    }

    /**
     * Setter method for emp.
     *
     * @param aEmp the new value for emp
     */
    public void setEmp(Set<Emp> aEmp) {
        emp = aEmp;
    }

    /**
     * Compares the key for this instance with another Dept.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class Dept and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof Dept)) {
            return false;
        }
        Dept that = (Dept) other;
        Object myDeptno = this.getDeptno();
        Object yourDeptno = that.getDeptno();
        if (myDeptno==null ? yourDeptno!=null : !myDeptno.equals(yourDeptno)) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another Dept.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Dept)) return false;
        return this.equalKeys(other) && ((Dept)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        if (getDeptno() == null) {
            i = 0;
        } else {
            i = getDeptno().hashCode();
        }
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[Dept |");
        sb.append(" deptno=").append(getDeptno());
        sb.append("]");
        return sb.toString();
    }

    /**
     * Return all elements of the primary key.
     *
     * @return Map of key names to values
     */
    public Map<String, Object> getPrimaryKey() {
        Map<String, Object> ret = new LinkedHashMap<String, Object>(6);
        ret.put("deptno", getDeptno());
        return ret;
    }

}
