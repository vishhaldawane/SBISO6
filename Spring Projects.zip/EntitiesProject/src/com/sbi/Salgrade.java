// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="SALGRADE")
@G9Class(tableName="SALGRADE", isPersistent=true)
public class Salgrade implements Serializable {

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Column(name="GRADE")
    @G9Attribute(isPersistent=true, columnName="GRADE")
    private BigDecimal grade;
    @Column(name="LOSAL")
    @G9Attribute(isPersistent=true, columnName="LOSAL")
    private BigDecimal losal;
    @Column(name="HISAL")
    @G9Attribute(isPersistent=true, columnName="HISAL")
    private BigDecimal hisal;

    /** Default constructor. */
    public Salgrade() {
        super();
    }

    /**
     * Access method for grade.
     *
     * @return the current value of grade
     */
    public BigDecimal getGrade() {
        return grade;
    }

    /**
     * Setter method for grade.
     *
     * @param aGrade the new value for grade
     */
    public void setGrade(BigDecimal aGrade) {
        grade = aGrade;
    }

    /**
     * Access method for losal.
     *
     * @return the current value of losal
     */
    public BigDecimal getLosal() {
        return losal;
    }

    /**
     * Setter method for losal.
     *
     * @param aLosal the new value for losal
     */
    public void setLosal(BigDecimal aLosal) {
        losal = aLosal;
    }

    /**
     * Access method for hisal.
     *
     * @return the current value of hisal
     */
    public BigDecimal getHisal() {
        return hisal;
    }

    /**
     * Setter method for hisal.
     *
     * @param aHisal the new value for hisal
     */
    public void setHisal(BigDecimal aHisal) {
        hisal = aHisal;
    }

}
