// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Association;
import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="ITEM")
@IdClass(Item.ItemId.class)
@G9Class(tableName="ITEM", isPersistent=true)
public class Item implements Serializable {

    /**
     * IdClass for primary key when using JPA annotations
     */
    public class ItemId implements Serializable {
        Ord ord;
        java.math.BigDecimal itemid;
    }

    /** Primary key. */
    protected static final String PK = "ItemItemPrimaryKey";

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Id
    @Column(name="ITEMID", nullable=false, precision=4)
    @G9Attribute(isPersistent=true, precision=4, columnName="ITEMID", isNotNull=true)
    private BigDecimal itemid;
    @Column(name="PRODID", precision=6)
    @G9Attribute(isPersistent=true, precision=6, columnName="PRODID")
    private BigDecimal prodid;
    @Column(name="ACTUALPRICE", precision=8, scale=2)
    @G9Attribute(isPersistent=true, precision=8, scale=2, columnName="ACTUALPRICE")
    private BigDecimal actualprice;
    @Column(name="QTY", precision=8)
    @G9Attribute(isPersistent=true, precision=8, columnName="QTY")
    private BigDecimal qty;
    @Column(name="ITEMTOT", precision=8, scale=2)
    @G9Attribute(isPersistent=true, precision=8, scale=2, columnName="ITEMTOT")
    private BigDecimal itemtot;
    @G9Attribute(isPrimaryKey=true, isUnique=true, isIndex=true)
    private ItemItemPrimaryKey itemItemPrimaryKey;
    @ManyToOne(optional=false)
    @Id
    @JoinColumn(name="ORDID", nullable=false)
    @G9Association(name="itemForeignKey", isPersistent=true, isMandatory=true, oppositeRole="item", ownerRole="ord", memberColumnNames="ORDID")
    private Ord ord;

    /** Default constructor. */
    public Item() {
        super();
    }

    /**
     * Access method for itemid.
     *
     * @return the current value of itemid
     */
    public BigDecimal getItemid() {
        return itemid;
    }

    /**
     * Setter method for itemid.
     *
     * @param aItemid the new value for itemid
     */
    public void setItemid(BigDecimal aItemid) {
        itemid = aItemid;
    }

    /**
     * Access method for prodid.
     *
     * @return the current value of prodid
     */
    public BigDecimal getProdid() {
        return prodid;
    }

    /**
     * Setter method for prodid.
     *
     * @param aProdid the new value for prodid
     */
    public void setProdid(BigDecimal aProdid) {
        prodid = aProdid;
    }

    /**
     * Access method for actualprice.
     *
     * @return the current value of actualprice
     */
    public BigDecimal getActualprice() {
        return actualprice;
    }

    /**
     * Setter method for actualprice.
     *
     * @param aActualprice the new value for actualprice
     */
    public void setActualprice(BigDecimal aActualprice) {
        actualprice = aActualprice;
    }

    /**
     * Access method for qty.
     *
     * @return the current value of qty
     */
    public BigDecimal getQty() {
        return qty;
    }

    /**
     * Setter method for qty.
     *
     * @param aQty the new value for qty
     */
    public void setQty(BigDecimal aQty) {
        qty = aQty;
    }

    /**
     * Access method for itemtot.
     *
     * @return the current value of itemtot
     */
    public BigDecimal getItemtot() {
        return itemtot;
    }

    /**
     * Setter method for itemtot.
     *
     * @param aItemtot the new value for itemtot
     */
    public void setItemtot(BigDecimal aItemtot) {
        itemtot = aItemtot;
    }

    /**
     * Access method for ord.
     *
     * @return the current value of ord
     */
    public Ord getOrd() {
        return ord;
    }

    /**
     * Setter method for ord.
     *
     * @param aOrd the new value for ord
     */
    public void setOrd(Ord aOrd) {
        ord = aOrd;
    }

    /** Temporary value holder for group key fragment ordOrdid */
    @G9Exclude
    private transient BigDecimal tempOrdOrdid;

    /**
     * Gets the key fragment ordid for member ord.
     * If this.ord is null, a temporary stored value for the key
     * fragment will be returned. The temporary value is set by setOrdOrdid.
     * This behavior is required by some persistence libraries to allow
     * fetching of objects in arbitrary order.
     *
     * @return Current (or temporary) value of the key fragment
     * @see Ord
     */
    @G9Exclude
    public BigDecimal getOrdOrdid() {
        return (getOrd() == null ? tempOrdOrdid : getOrd().getOrdid());
    }

    /**
     * Sets the key fragment ordid from member ord.
     * If this.ord is null, the passed value will be temporary
     * stored, and returned by subsequent calls to getOrdOrdid.
     * This behaviour is required by some persistence libraries to allow
     * fetching of objects in arbitrary order.
     *
     * @param aOrdid New value for the key fragment
     * @see Ord
     */
    public void setOrdOrdid(BigDecimal aOrdid) {
        if (getOrd() == null) {
            tempOrdOrdid = aOrdid;
        } else {
            getOrd().setOrdid(aOrdid);
        }
    }

    /**
     * Compares the key for this instance with another Item.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class Item and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof Item)) {
            return false;
        }
        Item that = (Item) other;
        Object myOrdOrdid = this.getOrdOrdid();
        Object yourOrdOrdid = that.getOrdOrdid();
        if (myOrdOrdid==null ? yourOrdOrdid!=null : !myOrdOrdid.equals(yourOrdOrdid)) {
            return false;
        }
        Object myItemid = this.getItemid();
        Object yourItemid = that.getItemid();
        if (myItemid==null ? yourItemid!=null : !myItemid.equals(yourItemid)) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another Item.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Item)) return false;
        return this.equalKeys(other) && ((Item)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        if (getOrdOrdid() == null) {
            i = 0;
        } else {
            i = getOrdOrdid().hashCode();
        }
        result = 37*result + i;
        if (getItemid() == null) {
            i = 0;
        } else {
            i = getItemid().hashCode();
        }
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[Item |");
        sb.append(" ordOrdid=").append(getOrdOrdid());
        sb.append(" itemid=").append(getItemid());
        sb.append("]");
        return sb.toString();
    }

    /**
     * Return all elements of the primary key.
     *
     * @return Map of key names to values
     */
    public Map<String, Object> getPrimaryKey() {
        Map<String, Object> ret = new LinkedHashMap<String, Object>(6);
        ret.put("ordOrdid", getOrdOrdid());
        ret.put("itemid", getItemid());
        return ret;
    }

}
