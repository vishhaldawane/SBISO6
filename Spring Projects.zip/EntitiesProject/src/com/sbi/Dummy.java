// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="DUMMY")
@G9Class(tableName="DUMMY", isPersistent=true)
public class Dummy implements Serializable {

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Column(name="DUMMY")
    @G9Attribute(isPersistent=true, columnName="DUMMY")
    private BigDecimal dummy;

    /** Default constructor. */
    public Dummy() {
        super();
    }

    /**
     * Access method for dummy.
     *
     * @return the current value of dummy
     */
    public BigDecimal getDummy() {
        return dummy;
    }

    /**
     * Setter method for dummy.
     *
     * @param aDummy the new value for dummy
     */
    public void setDummy(BigDecimal aDummy) {
        dummy = aDummy;
    }

}
