// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Association;
import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="EMP")
@G9Class(tableName="EMP", isPersistent=true)
public class Emp implements Serializable {

    /** Primary key. */
    protected static final String PK = "empno";

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Id
    @Column(name="EMPNO", unique=true, nullable=false, precision=4)
    @G9Attribute(isPersistent=true, precision=4, columnName="EMPNO", isPrimaryKey=true, isUnique=true, isNotNull=true, isIndex=true)
    private BigDecimal empno;
    @Column(name="ENAME", length=10)
    @G9Attribute(isPersistent=true, dbLength=10, columnName="ENAME")
    private String ename;
    @Column(name="JOB", length=9)
    @G9Attribute(isPersistent=true, dbLength=9, columnName="JOB")
    private String job;
    @Column(name="HIREDATE")
    @G9Attribute(isPersistent=true, columnName="HIREDATE")
    private LocalDateTime hiredate;
    @Column(name="SAL", precision=7, scale=2)
    @G9Attribute(isPersistent=true, precision=7, scale=2, columnName="SAL")
    private BigDecimal sal;
    @Column(name="COMM", precision=7, scale=2)
    @G9Attribute(isPersistent=true, precision=7, scale=2, columnName="COMM")
    private BigDecimal comm;
    @ManyToOne(optional=false)
    @JoinColumn(name="DEPTNO", nullable=false)
    @G9Association(name="empForeignKey", isPersistent=true, isMandatory=true, oppositeRole="emp", ownerRole="dept", memberColumnNames="DEPTNO")
    private Dept dept;
    @OneToMany(mappedBy="emp")
    @G9Association(name="empSelfKey", isPersistent=true, oppositeRole="emp", ownerRole="emp")
    private Set<Emp> empM;
    @ManyToOne
    @JoinColumn(name="MGR")
    @G9Association(name="empSelfKey", isPersistent=true, oppositeRole="empM", ownerRole="emp", memberColumnNames="MGR")
    private Emp emp;

    /** Default constructor. */
    public Emp() {
        super();
    }

    /**
     * Access method for empno.
     *
     * @return the current value of empno
     */
    public BigDecimal getEmpno() {
        return empno;
    }

    /**
     * Setter method for empno.
     *
     * @param aEmpno the new value for empno
     */
    public void setEmpno(BigDecimal aEmpno) {
        empno = aEmpno;
    }

    /**
     * Access method for ename.
     *
     * @return the current value of ename
     */
    public String getEname() {
        return ename;
    }

    /**
     * Setter method for ename.
     *
     * @param aEname the new value for ename
     */
    public void setEname(String aEname) {
        ename = aEname;
    }

    /**
     * Access method for job.
     *
     * @return the current value of job
     */
    public String getJob() {
        return job;
    }

    /**
     * Setter method for job.
     *
     * @param aJob the new value for job
     */
    public void setJob(String aJob) {
        job = aJob;
    }

    /**
     * Access method for hiredate.
     *
     * @return the current value of hiredate
     */
    public LocalDateTime getHiredate() {
        return hiredate;
    }

    /**
     * Setter method for hiredate.
     *
     * @param aHiredate the new value for hiredate
     */
    public void setHiredate(LocalDateTime aHiredate) {
        hiredate = aHiredate;
    }

    /**
     * Access method for sal.
     *
     * @return the current value of sal
     */
    public BigDecimal getSal() {
        return sal;
    }

    /**
     * Setter method for sal.
     *
     * @param aSal the new value for sal
     */
    public void setSal(BigDecimal aSal) {
        sal = aSal;
    }

    /**
     * Access method for comm.
     *
     * @return the current value of comm
     */
    public BigDecimal getComm() {
        return comm;
    }

    /**
     * Setter method for comm.
     *
     * @param aComm the new value for comm
     */
    public void setComm(BigDecimal aComm) {
        comm = aComm;
    }

    /**
     * Access method for dept.
     *
     * @return the current value of dept
     */
    public Dept getDept() {
        return dept;
    }

    /**
     * Setter method for dept.
     *
     * @param aDept the new value for dept
     */
    public void setDept(Dept aDept) {
        dept = aDept;
    }

    /**
     * Access method for empM.
     *
     * @return the current value of empM
     */
    public Set<Emp> getEmpM() {
        return empM;
    }

    /**
     * Setter method for empM.
     *
     * @param aEmpM the new value for empM
     */
    public void setEmpM(Set<Emp> aEmpM) {
        empM = aEmpM;
    }

    /**
     * Access method for emp.
     *
     * @return the current value of emp
     */
    public Emp getEmp() {
        return emp;
    }

    /**
     * Setter method for emp.
     *
     * @param aEmp the new value for emp
     */
    public void setEmp(Emp aEmp) {
        emp = aEmp;
    }

    /**
     * Compares the key for this instance with another Emp.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class Emp and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof Emp)) {
            return false;
        }
        Emp that = (Emp) other;
        Object myEmpno = this.getEmpno();
        Object yourEmpno = that.getEmpno();
        if (myEmpno==null ? yourEmpno!=null : !myEmpno.equals(yourEmpno)) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another Emp.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Emp)) return false;
        return this.equalKeys(other) && ((Emp)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        if (getEmpno() == null) {
            i = 0;
        } else {
            i = getEmpno().hashCode();
        }
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[Emp |");
        sb.append(" empno=").append(getEmpno());
        sb.append("]");
        return sb.toString();
    }

    /**
     * Return all elements of the primary key.
     *
     * @return Map of key names to values
     */
    public Map<String, Object> getPrimaryKey() {
        Map<String, Object> ret = new LinkedHashMap<String, Object>(6);
        ret.put("empno", getEmpno());
        return ret;
    }

}
