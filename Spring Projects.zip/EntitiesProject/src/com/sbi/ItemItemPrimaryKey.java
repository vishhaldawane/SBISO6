// Generated with g9.

package com.sbi;

import no.g9.domain.annotation.G9Group;

@G9Group(nameInModel="ItemPrimaryKey")
public class ItemItemPrimaryKey {
    int ord;
    int itemid;
}
