// Generated with g9.

package com.sbi;

import no.g9.domain.annotation.G9Group;

@G9Group(nameInModel="PriceIndex")
public class PricePriceIndex {
    int prodid;
    int startdate;
}
