// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Association;
import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="ORD")
@G9Class(tableName="ORD", isPersistent=true)
public class Ord implements Serializable {

    /** Primary key. */
    protected static final String PK = "ordid";

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Id
    @Column(name="ORDID", unique=true, nullable=false, precision=4)
    @G9Attribute(isPersistent=true, precision=4, columnName="ORDID", isPrimaryKey=true, isUnique=true, isNotNull=true, isIndex=true)
    private BigDecimal ordid;
    @Column(name="ORDERDATE")
    @G9Attribute(isPersistent=true, columnName="ORDERDATE")
    private LocalDateTime orderdate;
    @Column(name="COMMPLAN", length=1)
    @G9Attribute(isPersistent=true, dbLength=1, columnName="COMMPLAN")
    private String commplan;
    @Column(name="SHIPDATE")
    @G9Attribute(isPersistent=true, columnName="SHIPDATE")
    private LocalDateTime shipdate;
    @Column(name="TOTAL", precision=8, scale=2)
    @G9Attribute(isPersistent=true, precision=8, scale=2, columnName="TOTAL")
    private BigDecimal total;
    @OneToMany(mappedBy="ord")
    @G9Association(name="itemForeignKey", isPersistent=true, oppositeRole="ord", ownerRole="ord")
    private Set<Item> item;
    @ManyToOne(optional=false)
    @JoinColumn(name="CUSTID", nullable=false)
    @G9Association(name="ordForeignKey", isPersistent=true, isMandatory=true, oppositeRole="ord", ownerRole="customer", memberColumnNames="CUSTID")
    private Customer customer;

    /** Default constructor. */
    public Ord() {
        super();
    }

    /**
     * Access method for ordid.
     *
     * @return the current value of ordid
     */
    public BigDecimal getOrdid() {
        return ordid;
    }

    /**
     * Setter method for ordid.
     *
     * @param aOrdid the new value for ordid
     */
    public void setOrdid(BigDecimal aOrdid) {
        ordid = aOrdid;
    }

    /**
     * Access method for orderdate.
     *
     * @return the current value of orderdate
     */
    public LocalDateTime getOrderdate() {
        return orderdate;
    }

    /**
     * Setter method for orderdate.
     *
     * @param aOrderdate the new value for orderdate
     */
    public void setOrderdate(LocalDateTime aOrderdate) {
        orderdate = aOrderdate;
    }

    /**
     * Access method for commplan.
     *
     * @return the current value of commplan
     */
    public String getCommplan() {
        return commplan;
    }

    /**
     * Setter method for commplan.
     *
     * @param aCommplan the new value for commplan
     */
    public void setCommplan(String aCommplan) {
        commplan = aCommplan;
    }

    /**
     * Access method for shipdate.
     *
     * @return the current value of shipdate
     */
    public LocalDateTime getShipdate() {
        return shipdate;
    }

    /**
     * Setter method for shipdate.
     *
     * @param aShipdate the new value for shipdate
     */
    public void setShipdate(LocalDateTime aShipdate) {
        shipdate = aShipdate;
    }

    /**
     * Access method for total.
     *
     * @return the current value of total
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Setter method for total.
     *
     * @param aTotal the new value for total
     */
    public void setTotal(BigDecimal aTotal) {
        total = aTotal;
    }

    /**
     * Access method for item.
     *
     * @return the current value of item
     */
    public Set<Item> getItem() {
        return item;
    }

    /**
     * Setter method for item.
     *
     * @param aItem the new value for item
     */
    public void setItem(Set<Item> aItem) {
        item = aItem;
    }

    /**
     * Access method for customer.
     *
     * @return the current value of customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Setter method for customer.
     *
     * @param aCustomer the new value for customer
     */
    public void setCustomer(Customer aCustomer) {
        customer = aCustomer;
    }

    /**
     * Compares the key for this instance with another Ord.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class Ord and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof Ord)) {
            return false;
        }
        Ord that = (Ord) other;
        Object myOrdid = this.getOrdid();
        Object yourOrdid = that.getOrdid();
        if (myOrdid==null ? yourOrdid!=null : !myOrdid.equals(yourOrdid)) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another Ord.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Ord)) return false;
        return this.equalKeys(other) && ((Ord)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        if (getOrdid() == null) {
            i = 0;
        } else {
            i = getOrdid().hashCode();
        }
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[Ord |");
        sb.append(" ordid=").append(getOrdid());
        sb.append("]");
        return sb.toString();
    }

    /**
     * Return all elements of the primary key.
     *
     * @return Map of key names to values
     */
    public Map<String, Object> getPrimaryKey() {
        Map<String, Object> ret = new LinkedHashMap<String, Object>(6);
        ret.put("ordid", getOrdid());
        return ret;
    }

}
