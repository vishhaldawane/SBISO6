// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="BONUS")
@G9Class(tableName="BONUS", isPersistent=true)
public class Bonus implements Serializable {

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Column(name="ENAME", length=10)
    @G9Attribute(isPersistent=true, dbLength=10, columnName="ENAME")
    private String ename;
    @Column(name="JOB", length=9)
    @G9Attribute(isPersistent=true, dbLength=9, columnName="JOB")
    private String job;
    @Column(name="SAL")
    @G9Attribute(isPersistent=true, columnName="SAL")
    private BigDecimal sal;
    @Column(name="COMM")
    @G9Attribute(isPersistent=true, columnName="COMM")
    private BigDecimal comm;

    /** Default constructor. */
    public Bonus() {
        super();
    }

    /**
     * Access method for ename.
     *
     * @return the current value of ename
     */
    public String getEname() {
        return ename;
    }

    /**
     * Setter method for ename.
     *
     * @param aEname the new value for ename
     */
    public void setEname(String aEname) {
        ename = aEname;
    }

    /**
     * Access method for job.
     *
     * @return the current value of job
     */
    public String getJob() {
        return job;
    }

    /**
     * Setter method for job.
     *
     * @param aJob the new value for job
     */
    public void setJob(String aJob) {
        job = aJob;
    }

    /**
     * Access method for sal.
     *
     * @return the current value of sal
     */
    public BigDecimal getSal() {
        return sal;
    }

    /**
     * Setter method for sal.
     *
     * @param aSal the new value for sal
     */
    public void setSal(BigDecimal aSal) {
        sal = aSal;
    }

    /**
     * Access method for comm.
     *
     * @return the current value of comm
     */
    public BigDecimal getComm() {
        return comm;
    }

    /**
     * Setter method for comm.
     *
     * @param aComm the new value for comm
     */
    public void setComm(BigDecimal aComm) {
        comm = aComm;
    }

}
