// Generated with g9.

package com.sbi;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Version;

import no.g9.domain.annotation.G9Attribute;
import no.g9.domain.annotation.G9Class;
import no.g9.domain.annotation.G9Exclude;

@Entity(name="PRODUCT")
@G9Class(tableName="PRODUCT", isPersistent=true)
public class Product implements Serializable {

    /** Primary key. */
    protected static final String PK = "prodid";

    /**
     * The optimistic lock. Available via standard bean get/set operations.
     */
    @Version
    @Column(name="LOCK_FLAG")
    @G9Exclude
    private Integer lockFlag;

    /**
     * Access method for the lockFlag property.
     *
     * @return the current value of the lockFlag property
     */
    public Integer getLockFlag() {
        return lockFlag;
    }

    /**
     * Sets the value of the lockFlag property.
     *
     * @param aLockFlag the new value of the lockFlag property
     */
    public void setLockFlag(Integer aLockFlag) {
        lockFlag = aLockFlag;
    }

    @Id
    @Column(name="PRODID", unique=true, nullable=false, precision=6)
    @G9Attribute(isPersistent=true, precision=6, columnName="PRODID", isPrimaryKey=true, isUnique=true, isNotNull=true, isIndex=true)
    private BigDecimal prodid;
    @Column(name="DESCRIP", length=30)
    @G9Attribute(isPersistent=true, dbLength=30, columnName="DESCRIP")
    private String descrip;

    /** Default constructor. */
    public Product() {
        super();
    }

    /**
     * Access method for prodid.
     *
     * @return the current value of prodid
     */
    public BigDecimal getProdid() {
        return prodid;
    }

    /**
     * Setter method for prodid.
     *
     * @param aProdid the new value for prodid
     */
    public void setProdid(BigDecimal aProdid) {
        prodid = aProdid;
    }

    /**
     * Access method for descrip.
     *
     * @return the current value of descrip
     */
    public String getDescrip() {
        return descrip;
    }

    /**
     * Setter method for descrip.
     *
     * @param aDescrip the new value for descrip
     */
    public void setDescrip(String aDescrip) {
        descrip = aDescrip;
    }

    /**
     * Compares the key for this instance with another Product.
     *
     * @param other The object to compare to
     * @return True if other object is instance of class Product and the key objects are equal
     */
    private boolean equalKeys(Object other) {
        if (this==other) {
            return true;
        }
        if (!(other instanceof Product)) {
            return false;
        }
        Product that = (Product) other;
        Object myProdid = this.getProdid();
        Object yourProdid = that.getProdid();
        if (myProdid==null ? yourProdid!=null : !myProdid.equals(yourProdid)) {
            return false;
        }
        return true;
    }

    /**
     * Compares this instance with another Product.
     *
     * @param other The object to compare to
     * @return True if the objects are the same
     */
    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Product)) return false;
        return this.equalKeys(other) && ((Product)other).equalKeys(this);
    }

    /**
     * Returns a hash code for this instance.
     *
     * @return Hash code
     */
    @Override
    public int hashCode() {
        int i;
        int result = 17;
        if (getProdid() == null) {
            i = 0;
        } else {
            i = getProdid().hashCode();
        }
        result = 37*result + i;
        return result;
    }

    /**
     * Returns a debug-friendly String representation of this instance.
     *
     * @return String representation of this instance
     */
    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer("[Product |");
        sb.append(" prodid=").append(getProdid());
        sb.append("]");
        return sb.toString();
    }

    /**
     * Return all elements of the primary key.
     *
     * @return Map of key names to values
     */
    public Map<String, Object> getPrimaryKey() {
        Map<String, Object> ret = new LinkedHashMap<String, Object>(6);
        ret.put("prodid", getProdid());
        return ret;
    }

}
