package many2many;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class TestManyToMany {
	
	
	@Test
	public void addCustomersAndSubscriptions()
	{
			Customer cust1 = new Customer();
			cust1.setCustomerName("Jack");
			cust1.setCustomerEmailAddress("jack@gmail.com");
			
			
			Customer cust2 = new Customer();
			cust2.setCustomerName("Robert");
			cust2.setCustomerEmailAddress("robert@gmail.com");

			
			Subscription sub1 = new Subscription();
			sub1.setSubscriptionName("CDs");
			sub1.setSubscriptionDuration("1 month");
			
			Subscription sub2 = new Subscription();
			sub2.setSubscriptionName("DVDs");
			sub2.setSubscriptionDuration("2 months");
			
			Subscription sub3 = new Subscription();
			sub3.setSubscriptionName("Bookss");
			sub3.setSubscriptionDuration("3 months");
			
			
			EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
			System.out.println("Factory : "+factory);
			
			EntityManager manager = factory.createEntityManager();
			System.out.println("manager : "+manager);
			
			EntityTransaction trans = manager.getTransaction();
			System.out.println("Trans   : "+trans);
			trans.begin();			
				manager.persist(cust1);
				manager.persist(cust2);
				manager.persist(sub1);
				manager.persist(sub2);
				manager.persist(sub3);
			trans.commit();	
	}
	
	@Test
	public void testAllocateExistingSubscriptionToExistingCustomer()
	{
		
		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction trans = manager.getTransaction();
		System.out.println("Trans   : "+trans);
		trans.begin();
				Customer cust = manager.find(Customer.class, 14);
				Subscription sub1 = manager.find(Subscription.class, 15);
				Subscription sub2 = manager.find(Subscription.class, 16);
				Subscription sub3 = manager.find(Subscription.class, 17);
				
				Set<Subscription> subSet = new HashSet<Subscription>();
				
				subSet.add(sub1);
				subSet.add(sub2);
				subSet.add(sub3);
				
				cust.setSubscriptions(subSet);
				
				manager.merge(cust);
				
				trans.commit();
	}
	
}
