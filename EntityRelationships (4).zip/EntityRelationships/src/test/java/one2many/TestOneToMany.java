package one2many;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


public class TestOneToMany {
	
	@Test
	public void addDepartmentWithEmployees()
	{
			Department dept = new Department(10,"IT","Chicago");
			
			Employee3 emp1 = new Employee3(101,"Jack","Manager",5000,dept);
			Employee3 emp2 = new Employee3(102,"Jane","Clerk",2200,dept);
			Employee3 emp3 = new Employee3(103,"Julie","Analyst",3500,dept);
			Employee3 emp4 = new Employee3(104,"Julia","DBA",3300,dept);
			
			Set<Employee3> empSet = new HashSet<Employee3>();
			empSet.add(emp1);
			empSet.add(emp2);
			empSet.add(emp3);
			empSet.add(emp4);
			
			dept.setEmployees(empSet);
			
			Department dept2 = new Department(20,"Sales","New York");
			
			Employee3 emp5 = new Employee3(105,"Ramesh","Manager",4500,dept2);
			Employee3 emp6 = new Employee3(106,"Dinesh","Clerk",2100,dept2);
			Employee3 emp7 = new Employee3(107,"Haresh","Salesman",3300,dept2);
			Employee3 emp8 = new Employee3(108,"Jayesh","Salesman",3200,dept);
			
			Set<Employee3> empSet2 = new HashSet<Employee3>();
			empSet2.add(emp5);
			empSet2.add(emp6);
			empSet2.add(emp7);
			empSet2.add(emp8);
			
			dept.setEmployees(empSet);
			dept2.setEmployees(empSet2);
			
			EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
			System.out.println("Factory : "+factory);
			
			EntityManager manager = factory.createEntityManager();
			System.out.println("manager : "+manager);
			
			EntityTransaction trans = manager.getTransaction();
			System.out.println("Trans   : "+trans);
			trans.begin();			
				manager.persist(dept);
				manager.persist(dept2);
			trans.commit();	
	}

	
}
