package com.sbi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
//import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.view.InternalResourceView;

//C
@Controller
public class Example2Controller  {
	
	@RequestMapping("/example2.do")
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("handleRequest()...");
		
		ModelAndView mav = new ModelAndView("example1");
		mav.addObject("myMessage", "Welcome to Spring MVC Controller2");
		Student studObj = new Student();
		studObj.setRollno(2222);
		studObj.setName("Julie2");
		mav.addObject("myStudent", studObj);
		return mav;
	}
	public Example2Controller() {
		super();
		System.out.println("CONTROLLER2 : Example1Controller" );
	}

}
