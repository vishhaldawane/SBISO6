package com.sbi;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository("flightImpl2")
public class FlightRepositoryImpl2 implements FlightRepository {
	
	@Autowired	JdbcTemplate jdbcTemplate; //DataSource is passed to its ctor
	
	@Override
	public void updateFlight(Flight flightToUpdate) {
	String query="update flights set flightName=?,flightSource=?, flightDest=? where flightNumber=?";
	jdbcTemplate.update(query,
			flightToUpdate.getFlightName(),
			flightToUpdate.getFlightSource(),
			flightToUpdate.getFlightDest(), 
			flightToUpdate.getFlightNumber());
	}

	public FlightRepositoryImpl2() {
		System.out.println("flightImpl2 : FlightRepositoryImp2()");
	}

	public List<Flight> getAvailableFlights()  { 
		return null;
	}
}
