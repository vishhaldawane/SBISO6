package com.sbi.layer4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.layer2.Order;
import com.sbi.layer2.Payment;
import com.sbi.layer3.OrderRepository;
import com.sbi.layer3.PaymentRepository;
import com.sbi.layer3.ProductRepository;

@Service
public class OnlineShoppingImpl implements OnlineShopping {

	@Autowired OrderRepository orderRepo;
	@Autowired PaymentRepository paymentRepo;
	@Autowired ProductRepository productRepo;
	
	@Transactional
	public void placeOrder(Order order) {
		System.out.println("> PLACE ORDER STARTED < \n");
		//store the order
			orderRepo.processOrder(order);
		//process the payment
			Payment payment = new Payment();
			payment.setOrderId(order.getOrderId());
			payment.setAmount(order.getPrice() * 
					order.getQuantity());
			paymentRepo.storePayment(payment);
		//reduce the stock
			productRepo.reduceStock(order.getProductId(),
					order.getQuantity());
			
			System.out.println("\n > PLACE ORDER OVER < ");
	}

}
