package com.sbi.layer3;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ProductRepositoryImpl 
	implements ProductRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Transactional
	public void reduceStock(int productId, int qty) {
		System.out.println("> STARTED : reduceStock(int,int) ...");
		String query = "update tx_products "
		+ "set quantity=quantit-? where productid=?";
		//bad way to log the query
		System.out.println("SQL QUERY : "+query);
		jdbcTemplate.update(query , qty, productId);
		System.out.println("> FINISHED : reduceStock(int,int) ...");
	}

}
