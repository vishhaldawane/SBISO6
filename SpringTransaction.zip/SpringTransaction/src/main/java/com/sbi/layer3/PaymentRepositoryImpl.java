package com.sbi.layer3;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sbi.layer2.Payment;
@Repository
public class PaymentRepositoryImpl extends 
	AbstractRepository implements PaymentRepository {
	@Transactional
	public void storePayment(Payment payment) {
		System.out.println("> STARTED : storePayment(Payment)....");
		getEntityManager().persist(payment);
		System.out.println("> FINISHED: storePayment(Payment)....");

	}

}
