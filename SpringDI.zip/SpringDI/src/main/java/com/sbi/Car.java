package com.sbi;
public class Car implements Vehicle {
	
	Engine theEngine;
	
	public Car(Engine theEng) 
	{ 
		System.out.println("Car() ctor.."+this);
		theEngine = theEng;
	}
	void setCar() { 
		System.out.println("setCar() setter..");
	}
	public void drive() { //mandate to define this method
		theEngine.startTheEngine();
		System.out.println("Driving the Car....");
	}
}
