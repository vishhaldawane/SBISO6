package com.sbi;
public class VehicleFactory {
	public Vehicle getVehicle() {
		Piston pist = new Piston();
		Engine theEng = new Engine(pist);
		Car carObj = new Car(theEng);
		return carObj;
	}
}
