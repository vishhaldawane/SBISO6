package com.sbi;

public class Piston {
	
	public Piston() {
		System.out.println("Piston() ctor..."+this);
	}
	
	public void setPiston() {
		System.out.println("setPiston() setter...");
	}
	
	void fireThePiston() {
		System.out.println("Firing the Piston...");
	}
}
