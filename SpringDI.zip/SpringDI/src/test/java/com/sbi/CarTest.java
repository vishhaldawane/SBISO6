package com.sbi;
import org.junit.jupiter.api.Test;
public class CarTest {
	@Test public void createCarTest() {
		
		Piston pist1 = new Piston();
		Engine theEng1 = new Engine(pist1);
		Car carObj1 = new Car(theEng1);
		carObj1.drive();
		
		System.out.println("Car object  : "+carObj1.hashCode());

		Piston pist2 = new Piston();
		Engine theEng2 = new Engine(pist2);
		Car carObj2 = new Car(theEng2);
		carObj1.drive();
		
		System.out.println("Car object  : "+carObj2.hashCode());
		
		
	}
	
	@Test
	public void createVehicle() {
		VehicleFactory vehicleFactory = new VehicleFactory();
		Vehicle v1 = vehicleFactory.getVehicle();
		Vehicle v2 = vehicleFactory.getVehicle();
		Vehicle v3 = vehicleFactory.getVehicle();
	}
	
}
