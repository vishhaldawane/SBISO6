package com.sbi;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository //chef
public interface FlightRepository { //CRUD
	List<Flight> getAvailableFlights();
}
