package com.sbi;

import org.springframework.stereotype.Service;

@Service
public class OnlineServiceImpl implements OnlineService {

	@Override
	public void applyForCheque(int acno) {
		System.out.println("Applying for the cheque for acno : "+acno);
	}

	@Override
	public void stopCheque(int num) {
		System.out.println("stopping the cheque for acno : "+num);
	}

	@Override
	public void applyForCreditCard(int acno) {
		System.out.println("Applying for the credit card for acno : "+acno);

	}

	@Override
	public long getBalance(int num) {
		System.out.println("getting the balance for acno : "+num);
		return 6796956;
	}

}
