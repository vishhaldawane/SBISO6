package com.sbi;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingOutAspect {

	@After("execution(public * apply*(..))")
	public void log(JoinPoint joinPoint) {
		System.out.println(">> Its a common logging OUT method executed ....<< "+joinPoint+"\n");
	}
}

/*
   LoggingAspect logAsp = new LoggingAspect();
   logAsp.log();
  
 	OnlineService onlineServ = new ....
 	
 	logAsp.log();
 	onlineServ.applyForCheque();
 	
 	onlineServ.stopCheque();
 	
 	logAsp.log();
 	onlineServ.applyForCreditCard();
 	
 	onlineServ.getBalance();
   
 */
