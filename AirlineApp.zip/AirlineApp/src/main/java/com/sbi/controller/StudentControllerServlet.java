package com.sbi.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sbi.model.Student;

//C

@WebServlet("/studentController")
public class StudentControllerServlet
	extends HttpServlet {

	Student model = new Student();
	
	public StudentControllerServlet() {
		super();
		System.out.println("Controller : StudentControllerServlet");
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		model.setRollno(565656);
		model.setName("Julie");
		PrintWriter pw = resp.getWriter();
		req.setAttribute("myModelData", model);
		pw.println("<h1>Student Controller<h1>");
		RequestDispatcher rd = req.getRequestDispatcher("StudentView.jsp");
		rd.forward(req, resp);
	}
}

