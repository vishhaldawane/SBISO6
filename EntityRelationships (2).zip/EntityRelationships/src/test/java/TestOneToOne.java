import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import one2one.Employee;
import one2one.Passport;

public class TestOneToOne {
	
	@Test
	public void addEmployeeWithoutPassport() {
		
		Employee emp = new Employee();
		System.out.println("Blank emp created...");
		emp.setEmployeeName("SMITH");

		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();
			manager.persist(emp);
		tran.commit();
		
	}
	
	@Test
	public void addPassportWithoutEmployee() {
		
		Passport pass = new Passport();
		System.out.println("Blank passport created...");
		pass.setIssuedBy("Govt Of NEPAL");
		pass.setIssuedDate(LocalDate.now());
		pass.setExpiryDate(LocalDate.of(2032, 6, 7));
		
		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();
			manager.persist(pass);
		tran.commit();
		
	}
	
	@Test
	public void assignExistingPassportToExistingEmployee()
	{
		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();
			Employee foundEmp = manager.find(Employee.class, 1);
			Assertions.assertNotNull(foundEmp);
			Passport foundPass = manager.find(Passport.class, 2);
			
			foundEmp.setPassport(foundPass); //trigger the update query
			foundPass.setEmployee(foundEmp); //trigger the update query
			
			manager.merge(foundEmp);
			manager.merge(foundPass);
			
		tran.commit();
	}
	
	
	@Test
	public void assignNewPassportToExistingEmployee()
	{
		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();
			Employee foundEmp = manager.find(Employee.class, 3);
			Assertions.assertNotNull(foundEmp);
			
			Passport pass = new Passport();
			System.out.println("Blank passport created...");
			pass.setIssuedBy("Govt Of China");
			pass.setIssuedDate(LocalDate.now());
			pass.setExpiryDate(LocalDate.of(2023, 4, 5));
			
			foundEmp.setPassport(pass); //trigger the update query
			pass.setEmployee(foundEmp); //trigger the update query
			
			manager.persist(pass);
			manager.merge(foundEmp);
			
			
		tran.commit();
	}
	
	
	@Test
	public void assignExistingPassportToNewEmployee()
	{
		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();
			Passport foundPass = manager.find(Passport.class, 5);
			Assertions.assertNotNull(foundPass);
			
			Employee newEmp = new Employee();
			System.out.println("Blank emp created...");
			newEmp.setEmployeeName("ROBERT");
			newEmp.setPassport(foundPass); //trigger the update query
			foundPass.setEmployee(newEmp); //trigger the update query

			manager.persist(newEmp);
			manager.merge(foundPass);
			
		tran.commit();
	}

	
	@Test
	public void assignNewPassportToNewEmployee()
	{
		EntityManagerFactory factory  = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Factory : "+factory);
		
		EntityManager manager = factory.createEntityManager();
		System.out.println("manager : "+manager);
		
		EntityTransaction tran = manager.getTransaction();
		System.out.println("Trans   : "+tran);
		tran.begin();

		Passport newPass = new Passport();
		System.out.println("Blank passport created...");
		newPass.setIssuedBy("Govt Of Russia");
		newPass.setIssuedDate(LocalDate.now());
		newPass.setExpiryDate(LocalDate.of(2033, 4, 5));
		
		
			Employee newEmp = new Employee();
			System.out.println("Blank emp created...");
			newEmp.setEmployeeName("MILLER");
			newEmp.setPassport(newPass); //trigger the update query
			newPass.setEmployee(newEmp); //trigger the update query

			manager.persist(newEmp);
			manager.persist(newPass);
			
		tran.commit();
	}
}
