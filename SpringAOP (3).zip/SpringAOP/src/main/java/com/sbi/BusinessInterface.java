package com.sbi;

import org.springframework.stereotype.Component;

@Component
public interface BusinessInterface {
	void someBusinessMethod() throws BusinessException;
}
