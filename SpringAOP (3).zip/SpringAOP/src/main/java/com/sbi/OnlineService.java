package com.sbi;

import org.springframework.stereotype.Service;

@Service
public interface OnlineService {
	void applyForCheque(int acno);
	void stopCheque(int num);
	void applyForCreditCard(int acno);
	long getBalance(int num);
	
}
