package com.sbi.repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.entity.Flight;

@Repository
public interface FlightRepository {

	//CRUD
		 void    insertFlight(Flight flight); //C
	List<Flight> selectAllFlights();	 //RA
	     Flight  selectFlight(int flno); //RS
	     void    updateFlight(Flight flight); //U
	     void    deleteFlight(Flight flight); //D
}
