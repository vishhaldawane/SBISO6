package com.sbi.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.layer1.Flight;
import com.sbi.demo.layer3.FlightAlreadyExistsException;
import com.sbi.demo.layer3.FlightNotFoundException;
import com.sbi.demo.layer3.FlightService;

@RestController
@RequestMapping("/flights")
public class FlightControllerImpl implements FlightController {

	@Autowired
	FlightService flightService;

	public FlightControllerImpl() {
		System.out.println("FlightControllerImpl() ctor...");
	}
	
	@GetMapping("/getFlight/{src}")
	public Flight getFlight(@PathVariable("src") String f_src) {
		System.out.println("getFlight("+f_src+")");
		Flight flight = new Flight();
		try {
			flight = flightService.searchFlightBySource(f_src);
		} catch (FlightNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flight;
	}
	
	@GetMapping("/getFlights")
	public List<Flight> getFlights() {
		System.out.println("getFlights()");
		return flightService.getFlightsService();
	}
	
	@GetMapping("/getFlights/{flno}")
	public Flight getFlights(@PathVariable("flno")
				int flightNumber) throws FlightNotFoundException 
	{
		System.out.println("getFlights(int)");
		Flight flight= null;
		try {
			flight = flightService.getFlightService(flightNumber);
		} catch (FlightNotFoundException e) {
			throw e;
		}
		return flight;
	}
	
	@PostMapping("/addFlight")
	public void addFlight(@RequestBody
				Flight flight) throws FlightAlreadyExistsException 
	{
		System.out.println("addFlight(Flight)");
		try {
			flightService.addFlightService(flight);
		} catch (FlightAlreadyExistsException e) {
			throw e;
		}
	}
	@PutMapping("/updateFlight")
	public void updateFlight(@RequestBody
				Flight flight) throws FlightNotFoundException 
	{
		System.out.println("updateFlight(Flight)");
		try {
			flightService.modifyFlightService(flight);
		} catch (FlightNotFoundException e) {
			throw e;
		}
	}
	
	@DeleteMapping("/deleteFlight/{flno}")
	public void updateFlight(@PathVariable("flno")
				int flightNo) throws FlightNotFoundException 
	{
		System.out.println("deleteFlight(flno)");
		try {
			flightService.deleteFlightService(flightNo);
		} catch (FlightNotFoundException e) {
			throw e;
		}
	}
}
