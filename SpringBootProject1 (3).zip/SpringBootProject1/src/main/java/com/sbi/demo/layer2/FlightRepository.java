package com.sbi.demo.layer2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sbi.demo.layer1.Flight;

@Repository
public interface FlightRepository 

	extends CrudRepository<Flight,Integer> {
	//crud methods
}



/*class FlightRepositoryImpl implements FlightRepository 
{
	
}*/
