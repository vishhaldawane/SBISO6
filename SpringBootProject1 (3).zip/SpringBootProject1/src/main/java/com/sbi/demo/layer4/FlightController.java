package com.sbi.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.layer1.Flight;
import com.sbi.demo.layer3.FlightService;

@RestController
public interface FlightController {
	
	Flight getFlight(String src);
	
}
