package com.sbi.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.layer1.Flight;

@Service
public interface FlightService {

	Flight       searchFlightBySource(String src) throws FlightNotFoundException;
	void         addFlightService(Flight flight) throws FlightAlreadyExistsException;
	void         modifyFlightService(Flight flight) throws FlightNotFoundException;
	void   		 deleteFlightService(int flightId) throws FlightNotFoundException;
	Flight 		 getFlightService(int flightId) throws FlightNotFoundException;
	List<Flight> getFlightsService();
	
}
