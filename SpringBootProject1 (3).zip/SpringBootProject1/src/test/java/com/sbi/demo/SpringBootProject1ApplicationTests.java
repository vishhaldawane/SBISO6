package com.sbi.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.demo.layer1.Flight;
import com.sbi.demo.layer2.FlightRepository;
import com.sbi.demo.layer3.FlightNotFoundException;
import com.sbi.demo.layer3.FlightService;

@SpringBootTest
class SpringBootProject1ApplicationTests {

	@Autowired
	Flight flight;
	
	@Autowired
	FlightRepository flightRepo;
	
	@Test
	void createFlight() {
		
		Assertions.assertNotNull(flight);
		
		flight.setFlightName("Air France");
		flight.setFlightSource("Mumbai");
		flight.setFlightDestination("Paris");
		
		flightRepo.save(flight);
		System.out.println("flight PERSISTED...");
	}
	
	
	@Autowired
	FlightService flightService;
	
	@Test
	void testService() {
		
		Flight flight;
		try {
			flight = flightService.searchFlightBySource("Mumbai");
			Assertions.assertNotNull(flight);
			System.out.println("FlightNo   : "+flight.getFlightNumber());
			System.out.println("FlightNM   : "+flight.getFlightName());
			System.out.println("FlightSRC  : "+flight.getFlightSource());
			System.out.println("FlightDEST : "+flight.getFlightDestination());
			
		} catch (FlightNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
