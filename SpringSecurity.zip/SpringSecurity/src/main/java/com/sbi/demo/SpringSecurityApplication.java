package com.sbi.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityApplication.class, args);
		System.out.println("SpringSecurityApplication started...");
	}

}
/*
				SpringSecurityApplication
						|
	------------------------------------------------
	|		|		|		|		|			|		
	db		pojo	repo	service	security controller
	|		|		|		|		config		|	
 users	 MyUser		|	MyUserDetails	|	 UserResource
					|	Service			|
				-----		|	MySecurityConfiguration
				|			|
		MyUserRepo		UserDetails
						|
					MyUserDetails
*/		



