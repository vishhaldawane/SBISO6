package com.sbi;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	@Before("execution(public * apply*(..))")
	public void log() {
		System.out.println("\n>> Its a common logging method executed ....<<");
		
	}
}

/*
   LoggingAspect logAsp = new LoggingAspect();
   logAsp.log();
  
 	OnlineService onlineServ = new ....
 	
 	logAsp.log();
 	onlineServ.applyForCheque();
 	
 	onlineServ.stopCheque();
 	
 	logAsp.log();
 	onlineServ.applyForCreditCard();
 	
 	onlineServ.getBalance();
   
 */
