import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.OnlineService;



@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations= {"classpath:myspring3.xml"} )
public class OrderTest {
	
	@Autowired
	private OnlineService onlineService;
	
	@Test
	public void testLogAspect() {
		
		onlineService.applyForCheque(123);
		onlineService.stopCheque(122);
		onlineService.applyForCreditCard(223);
		onlineService.getBalance(223);
		
	}
	
}




