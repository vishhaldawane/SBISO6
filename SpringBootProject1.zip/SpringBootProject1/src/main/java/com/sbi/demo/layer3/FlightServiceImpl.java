package com.sbi.demo.layer3;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.layer1.Flight;
import com.sbi.demo.layer2.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepo;
	
	@Override
	public Flight searchFlightBySource(String src) {
		System.out.println("BL: ");
		
			Iterable<Flight> iterable = flightRepo.findAll();
			Iterator<Flight> iterator = iterable.iterator();
			
			boolean flightFound=false;
			
			while(iterator.hasNext()) {
				Flight flight = iterator.next();
				if(flight.getFlightSource().equalsIgnoreCase(src))
				{
					flightFound=true;
					return flight;
				}
			}
			if(flightFound==false)
				return null;
		return null;
	}

}
