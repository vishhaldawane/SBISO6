package com.sbi.demo.layer3;

import org.springframework.stereotype.Service;

import com.sbi.demo.layer1.Flight;

@Service
public interface FlightService {

	Flight searchFlightBySource(String src);
		
	
}
