package com.sbi.demo.layer3;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class FlightAlreadyExistsAdvice {

	@ResponseBody
	@ExceptionHandler(FlightAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	String flightNotFoundHandler(FlightAlreadyExistsException ex) {
		System.out.println("CONTROLLER ADVICE 2 : "+ex.getMessage());
		return ex.getMessage();
	}
}
