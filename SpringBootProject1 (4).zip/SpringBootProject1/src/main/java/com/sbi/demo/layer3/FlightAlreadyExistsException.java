package com.sbi.demo.layer3;

public class FlightAlreadyExistsException extends Exception {

	public FlightAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
