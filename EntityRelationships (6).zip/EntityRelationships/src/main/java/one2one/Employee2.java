package one2one;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity @Table(name="emp_2")
public class Employee2 {//one employee got one passport
	@Id	@GeneratedValue private int employeeId;
		private String employeeName;
		@OneToOne( cascade = CascadeType.ALL)
		@JoinColumn(name="pass_no",unique = true) //to define a FK column
		Passport2 passport; //hasA 
				
	public Passport2 getPassport() {
			return passport;
		}
		public void setPassport(Passport2 passport) {
			this.passport = passport;
		}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
}
