package many2many;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
	@Id	@GeneratedValue
	@Column(name="cust_id")	 private int customerId;
	@Column(name="cust_name")private String customerName;
	@Column(name="cust_email")private String customerEmailAddress;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="customer_subscription_link",
	 joinColumns = { @JoinColumn(name="cid")},
	 inverseJoinColumns = {@JoinColumn(name="sid")}
	)
	private Set<Subscription> subscriptions = new HashSet<Subscription>();
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmailAddress() {
		return customerEmailAddress;
	}
	public void setCustomerEmailAddress(String customerEmailAddress) {
		this.customerEmailAddress = customerEmailAddress;
	}
	public Set<Subscription> getSubscriptions() {
		return subscriptions;
	}
	public void setSubscriptions(Set<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}
	
}
