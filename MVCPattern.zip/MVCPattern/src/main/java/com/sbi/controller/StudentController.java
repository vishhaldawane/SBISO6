package com.sbi.controller;

import com.sbi.model.Student;
import com.sbi.view.StudentView;

//C
public class StudentController {
	
	Student model; //2 fields rollno,name
	StudentView view;
	
	public StudentController(Student model, StudentView view) {
		super();
		this.model = model;
		this.view = view;
	}
	
	public void setStudentRollNumber(int roll) {
		model.setRollno(roll);
	}
	public int getStudentRollNumber() {
		return model.getRollno();
	}
	public void setStudentName(String name) {
		model.setName(name);
	}
	public String getStudentName() {
		return model.getName();
	}
	public void updateView() {//DONT FORGET THIS
		view.printStudentDetails(model);
	}
}
