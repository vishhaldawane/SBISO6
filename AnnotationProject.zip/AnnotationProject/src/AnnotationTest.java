import java.lang.annotation.Annotation;

public class AnnotationTest {
	public static void main(String[] args) {
		
		MyJar myJar = new MyJar();
		
		Class theClass = myJar.getClass();
		
		Annotation annos[] = theClass.getAnnotations();
		
		for (Annotation annotation : annos) {
			System.out.println("Annotation is : "+annotation);
			if( annotation instanceof PickleJar) {
				PickleJar pj = (PickleJar) annotation;
				if(pj.type().equals("lemon")) {
					System.out.println("its sour..");
				}
				else if(pj.type().equals("chilly")) {
					System.out.println("its spicy..");
				}
				else if(pj.type().equals("garlic")) {
					System.out.println("its pungent..");
				}
			}
		}
		
		
	}
}
/*
  	NLP
  
  	every instance of an "Object class" 
  	got a method called getClass 
  	that returns an instance of "class Class"
  
*/ 





