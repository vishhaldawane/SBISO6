@PickleJar(type="lemon", 
			cost=60)
public class MyJar {

	int size;
	public void tasteIt() {
		
	}
}
