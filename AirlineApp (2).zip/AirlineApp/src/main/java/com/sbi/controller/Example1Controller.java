package com.sbi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.view.InternalResourceView;

//C
public class Example1Controller implements Controller {
	
	
	public Example1Controller() {
		super();
		System.out.println("CONTROLLER : Example1Controller" );
	}

	public ModelAndView handleRequest(
			
		HttpServletRequest request, 
		HttpServletResponse response) throws Exception {
		//V
		System.out.println("handleRequest()...");
		View theView = new InternalResourceView("example1.jsp");//the jsp page
		//M and V
		ModelAndView mav = new ModelAndView(theView);
		mav.addObject("myMessage", "Welcome to Spring MVC");
		return mav;
	}

}
